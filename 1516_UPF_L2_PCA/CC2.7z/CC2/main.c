#include <stdio.h>
#include <stdlib.h>

#include "declaration.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	TableauVecteur a = {3,{{1,1,1},{1, -1, -1},{(-1, 1, 0}}} b = {3,{{0, 0, 1},{1, 0, -1},{1, 0, 1}}};
	afficheProduitTableauVecteur(a,b);
	return 0;
}
