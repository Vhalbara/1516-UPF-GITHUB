#ifndef DECLARATION_H
#define DECLARATION_H

#include <stidio.h>
#include <stdlib.h>

#definne N 25

typedef struct
{
	float x;
	float y;
	float z;
}Vecteur;

typedef struct
{
	int taille;
	Vecteur tab[N];
}TableauVecteur;

float produitScalaire(Vecteur arg1, Vecteur arg2);
void afficheVecteur (Vecteur output, char* name);
void afficheProduit (Vecteur arg1, Vecteur arg2);
void afficheProduitTableauVecteur (TableauVecteur arg1, TableauVecteur arg2);
#endif
