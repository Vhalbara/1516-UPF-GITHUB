#include "declartion.h"

float produitScalaire(Vecteur arg1, Vecteur arg2)
{
	float result = arg1.x * arg2.x + arg1.y * arg2.y + arg1.z * arg2.z;
	return result;
}

void afficheVecteur (Vecteur output, char* name)
{
	printf("\nVecteur %s",name);
	printf("x = %.3f",output.x);	
	printf("y = %.3f",output.y);	
	printf("z = %.3f",output.z);	
}

void afficheProduit (Vecteur arg1, Vecteur arg2)
{
	afficheVecteur();
	afficheVecteur();
	printf("\nproduit scalaire = %.3f\n",produitScalaire(arg1, arg2));	
}

void afficheProduitTableauVecteur (TableauVecteur arg1, TableauVecteur arg2)
{
	int position , taille_max = arg1.taille;
	if(arg1.taille > arg2.taille)
		taille_max = arg2.taille;
	for(position = 0; position < taille_max; position++)
	{
		afficheProduit(arg1.tab[position],arg2.tab[position]);
	}
}
